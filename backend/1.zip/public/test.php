TEST FILE - If you can see this, the deployment is working!
Current time: <?php echo date('Y-m-d H:i:s'); ?>