<?php
echo "=== GITHUB ACTIONS DEPLOYMENT TEST ===\n";
echo "If you see this file, GitHub Actions deployment is working!\n";
echo "Deployment time: " . date('Y-m-d H:i:s') . "\n";
echo "This file was created and pushed via GitHub Actions.\n";
echo "File location: " . __FILE__ . "\n";
echo "=== TEST SUCCESSFUL ===\n";
?>