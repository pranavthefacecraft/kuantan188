

<?php $__env->startSection('title', 'Bookings Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid">
    <!-- Header Actions -->
    <div class="card">
        <div class="card-body" style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h2 style="margin: 0; font-size: 1.5rem; font-weight: 600;">Bookings Management</h2>
                <p style="margin: 0.5rem 0 0 0; color: var(--on-surface-variant);">View and manage customer bookings</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <select class="btn btn-outline" style="padding: 0.5rem 1rem;">
                    <option>All Statuses</option>
                    <option>Confirmed</option>
                    <option>Pending</option>
                    <option>Cancelled</option>
                </select>
                <button class="btn btn-outline">
                    <span class="material-icons" style="font-size: 18px;">download</span>
                    Export
                </button>
            </div>
        </div>
    </div>

    <!-- Bookings Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Booking Reference</th>
                            <th>Customer</th>
                            <th>Event</th>
                            <th>Country</th>
                            <th>Tickets</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600; color: var(--primary);">
                                        <?php echo e($booking->booking_reference); ?>

                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div style="font-weight: 500;"><?php echo e($booking->customer_name); ?></div>
                                        <div style="font-size: 0.875rem; color: var(--on-surface-variant);">
                                            <?php echo e($booking->customer_email); ?>

                                        </div>
                                        <?php if($booking->customer_phone): ?>
                                            <div style="font-size: 0.875rem; color: var(--on-surface-variant);">
                                                <?php echo e($booking->customer_phone); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div style="font-weight: 500;"><?php echo e($booking->ticket->event->name); ?></div>
                                        <div style="font-size: 0.875rem; color: var(--on-surface-variant);">
                                            <?php echo e($booking->ticket->event->date->format('M j, Y')); ?>

                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                                        <span class="material-icons" style="font-size: 16px; color: var(--accent);">public</span>
                                        <?php echo e($booking->ticket->country->name); ?>

                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div><?php echo e($booking->adult_quantity); ?> Adults</div>
                                        <?php if($booking->child_quantity > 0): ?>
                                            <div style="font-size: 0.875rem; color: var(--on-surface-variant);">
                                                <?php echo e($booking->child_quantity); ?> Children
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-weight: 600; color: var(--success);">
                                        RM <?php echo e(number_format($booking->total_amount, 2)); ?>

                                    </div>
                                    <?php if($booking->adult_quantity > 0 && $booking->child_quantity > 0): ?>
                                        <div style="font-size: 0.75rem; color: var(--on-surface-variant);">
                                            A: RM<?php echo e(number_format($booking->ticket->adult_price, 2)); ?> × <?php echo e($booking->adult_quantity); ?><br>
                                            C: RM<?php echo e(number_format($booking->ticket->child_price, 2)); ?> × <?php echo e($booking->child_quantity); ?>

                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($booking->status === 'confirmed'): ?>
                                        <span class="badge badge-success">
                                            <span class="material-icons" style="font-size: 12px;">check_circle</span>
                                            Confirmed
                                        </span>
                                    <?php elseif($booking->status === 'pending'): ?>
                                        <span class="badge badge-warning">
                                            <span class="material-icons" style="font-size: 12px;">schedule</span>
                                            Pending
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-error">
                                            <span class="material-icons" style="font-size: 12px;">cancel</span>
                                            Cancelled
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div><?php echo e($booking->created_at->format('M j, Y')); ?></div>
                                    <div style="font-size: 0.875rem; color: var(--on-surface-variant);">
                                        <?php echo e($booking->created_at->format('H:i')); ?>

                                    </div>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 0.5rem;">
                                        <?php if($booking->status === 'pending'): ?>
                                            <button class="btn btn-outline" 
                                                    style="padding: 0.25rem 0.5rem; background: var(--success); color: white;"
                                                    onclick="updateBookingStatus('<?php echo e($booking->id); ?>', 'confirmed')">
                                                <span class="material-icons" style="font-size: 16px;">check</span>
                                            </button>
                                        <?php endif; ?>
                                        <a href="#" class="btn btn-outline" style="padding: 0.25rem 0.5rem;">
                                            <span class="material-icons" style="font-size: 16px;">visibility</span>
                                        </a>
                                        <a href="#" class="btn btn-outline" style="padding: 0.25rem 0.5rem;">
                                            <span class="material-icons" style="font-size: 16px;">email</span>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 3rem; color: var(--on-surface-variant);">
                                    <div style="display: flex; flex-direction: column; align-items: center; gap: 1rem;">
                                        <span class="material-icons" style="font-size: 48px; opacity: 0.3;">book_online</span>
                                        <div>
                                            <div style="font-size: 1.125rem; font-weight: 500; margin-bottom: 0.5rem;">No bookings found</div>
                                            <div>Bookings will appear here when customers make purchases</div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($bookings->hasPages()): ?>
                <div style="margin-top: 1.5rem;">
                    <?php echo e($bookings->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function updateBookingStatus(bookingId, status) {
        if (confirm('Are you sure you want to update this booking status?')) {
            fetch(`/api/bookings/${bookingId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ status: status })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error updating booking status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error updating booking status');
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kuantan188\kuantan188\backend\resources\views/admin/bookings.blade.php ENDPATH**/ ?>