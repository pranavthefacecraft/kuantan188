

<?php $__env->startSection('title', 'Google Reviews Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h1 class="content-title">Google Reviews Management</h1>
            <p class="content-subtitle">Manage and sync Google Reviews for Menara Kuantan 188</p>
        </div>
        <div>
            <form action="<?php echo e(route('admin.reviews.sync')); ?>" method="POST" style="display: inline;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure you want to sync Google Reviews? This may take a few moments.')">
                    <span class="material-icons me-2">sync</span>
                    Sync Google Reviews
                </button>
            </form>
        </div>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <span class="material-icons me-2">check_circle</span>
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <span class="material-icons me-2">error</span>
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('sync_output')): ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <strong>Sync Output:</strong>
        <pre class="mt-2"><?php echo e(session('sync_output')); ?></pre>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-3">
            <div class="card bg-primary text-white">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1 text-white-50">Total Reviews</h6>
                            <h3 class="mb-0 fw-bold"><?php echo e($stats['total_reviews']); ?></h3>
                        </div>
                        <span class="material-icons" style="font-size: 2rem; opacity: 0.4;">star</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card bg-success text-white">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1 text-white-50">Active Reviews</h6>
                            <h3 class="mb-0 fw-bold"><?php echo e($stats['active_reviews']); ?></h3>
                        </div>
                        <span class="material-icons" style="font-size: 2rem; opacity: 0.4;">visibility</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card bg-warning text-white">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1 text-white-50">Average Rating</h6>
                            <h3 class="mb-0 fw-bold"><?php echo e(number_format($stats['average_rating'], 1)); ?></h3>
                        </div>
                        <span class="material-icons" style="font-size: 2rem; opacity: 0.4;">star_rate</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card bg-info text-white">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1 text-white-50">Last Sync</h6>
                            <p class="mb-0 fw-bold h5">
                                <?php if($stats['latest_sync']): ?>
                                    <?php echo e($stats['latest_sync']->diffForHumans()); ?>

                                <?php else: ?>
                                    Never
                                <?php endif; ?>
                            </p>
                        </div>
                        <span class="material-icons" style="font-size: 2rem; opacity: 0.4;">access_time</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reviews Table -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <span class="material-icons me-2">rate_review</span>
            All Reviews (<?php echo e($reviews->total()); ?>)
        </h5>
    </div>
    <div class="card-body p-0">
        <?php if($reviews->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Author</th>
                            <th>Rating</th>
                            <th>Review</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e(!$review->is_active ? 'table-secondary' : ''); ?>">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php if($review->author_photo_url): ?>
                                            <img src="<?php echo e($review->author_photo_url); ?>" 
                                                 alt="<?php echo e($review->author_name); ?>" 
                                                 class="rounded-circle me-2"
                                                 style="width: 32px; height: 32px;">
                                        <?php else: ?>
                                            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2" 
                                                 style="width: 32px; height: 32px; font-size: 12px;">
                                                <?php echo e(substr($review->author_name, 0, 2)); ?>

                                            </div>
                                        <?php endif; ?>
                                        <strong><?php echo e($review->author_name); ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= $review->rating): ?>
                                                <span class="material-icons text-warning" style="font-size: 16px;">star</span>
                                            <?php else: ?>
                                                <span class="material-icons text-muted" style="font-size: 16px;">star_border</span>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                        <span class="ms-1 text-muted">(<?php echo e($review->rating); ?>)</span>
                                    </div>
                                </td>
                                <td>
                                    <div style="max-width: 300px;">
                                        <p class="mb-0 text-truncate" title="<?php echo e($review->text); ?>">
                                            <?php echo e(Str::limit($review->text, 80)); ?>

                                        </p>
                                        <?php if($review->like_count > 0): ?>
                                            <small class="text-muted">
                                                <span class="material-icons" style="font-size: 14px;">thumb_up</span>
                                                <?php echo e($review->like_count); ?> likes
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo e($review->review_time->format('M j, Y')); ?><br>
                                        <?php echo e($review->review_time->diffForHumans()); ?>

                                    </small>
                                </td>
                                <td>
                                    <?php if($review->is_active): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Hidden</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('admin.reviews.toggle-status', $review)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-sm <?php echo e($review->is_active ? 'btn-outline-danger' : 'btn-outline-success'); ?>" 
                                                title="<?php echo e($review->is_active ? 'Hide Review' : 'Show Review'); ?>">
                                            <span class="material-icons" style="font-size: 16px;">
                                                <?php echo e($review->is_active ? 'visibility_off' : 'visibility'); ?>

                                            </span>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php if($review->reply_from_owner): ?>
                                <tr class="table-light">
                                    <td colspan="6">
                                        <div class="ms-4">
                                            <div class="d-flex align-items-center mb-1">
                                                <span class="material-icons text-primary me-1" style="font-size: 16px;">business</span>
                                                <strong class="text-primary">Owner Response:</strong>
                                                <small class="text-muted ms-2"><?php echo e($review->reply_time->format('M j, Y')); ?></small>
                                            </div>
                                            <p class="mb-0 text-muted"><?php echo e($review->reply_from_owner); ?></p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <span class="material-icons text-muted" style="font-size: 4rem;">star_border</span>
                <h5 class="text-muted mt-2">No Reviews Found</h5>
                <p class="text-muted">Click "Sync Google Reviews" to fetch reviews from Google Places API</p>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if($reviews->hasPages()): ?>
        <div class="card-footer">
            <div class="d-flex justify-content-center">
                <?php echo e($reviews->links()); ?>

            </div>
        </div>
    <?php endif; ?>
</div>

<style>
.content-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 2rem;
    border-radius: 15px;
    margin-bottom: 2rem;
}

/* Force horizontal layout for statistics cards */
.row {
    display: flex !important;
    flex-wrap: wrap !important;
}

.col-3 {
    flex: 0 0 25% !important;
    max-width: 25% !important;
    padding-right: 15px;
    padding-left: 15px;
}

@media (max-width: 768px) {
    .col-3 {
        flex: 0 0 50% !important;
        max-width: 50% !important;
    }
}

@media (max-width: 576px) {
    .col-3 {
        flex: 0 0 100% !important;
        max-width: 100% !important;
    }
}

.content-title {
    font-size: 2rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.content-subtitle {
    opacity: 0.9;
    margin-bottom: 0;
}

.card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);
}

.table-hover tbody tr:hover {
    background-color: rgba(0, 123, 255, 0.05);
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    border-radius: 10px;
    padding: 0.75rem 1.5rem;
    font-weight: 500;
}

.btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.alert {
    border: none;
    border-radius: 10px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kuantan188\kuantan188\backend\resources\views/admin/reviews.blade.php ENDPATH**/ ?>