<?php $__env->startSection('title', 'Create Account'); ?>
<?php $__env->startSection('subtitle', 'Join Kuantan188 admin dashboard'); ?>
<?php $__env->startSection('icon', 'person_add'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="name" class="form-label">Full Name</label>
        <input id="name" 
               type="text" 
               class="form-input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="name" 
               value="<?php echo e(old('name')); ?>" 
               required 
               autocomplete="name" 
               autofocus
               placeholder="Enter your full name">

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <span class="material-icons" style="font-size: 14px;">error</span>
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="email" class="form-label">Email Address</label>
        <input id="email" 
               type="email" 
               class="form-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="email" 
               value="<?php echo e(old('email')); ?>" 
               required 
               autocomplete="email"
               placeholder="Enter your email">

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <span class="material-icons" style="font-size: 14px;">error</span>
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="password" class="form-label">Password</label>
        <input id="password" 
               type="password" 
               class="form-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="password" 
               required 
               autocomplete="new-password"
               placeholder="Create a strong password">

        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <span class="material-icons" style="font-size: 14px;">error</span>
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="password-confirm" class="form-label">Confirm Password</label>
        <input id="password-confirm" 
               type="password" 
               class="form-input" 
               name="password_confirmation" 
               required 
               autocomplete="new-password"
               placeholder="Confirm your password">
    </div>

    <div class="checkbox-group">
        <input class="checkbox-input" 
               type="checkbox" 
               name="terms" 
               id="terms" 
               required>
        <label class="checkbox-label" for="terms">
            I agree to the <a href="#" style="color: var(--primary);">Terms of Service</a> and <a href="#" style="color: var(--primary);">Privacy Policy</a>
        </label>
    </div>

    <button type="submit" class="btn btn-primary">
        <span class="material-icons" style="font-size: 18px;">person_add</span>
        Create Account
    </button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <p class="auth-footer-text">
        Already have an account? 
        <a href="<?php echo e(route('login')); ?>" class="auth-footer-link">Sign in here</a>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kuantan188\kuantan188\backend\resources\views/auth/register.blade.php ENDPATH**/ ?>