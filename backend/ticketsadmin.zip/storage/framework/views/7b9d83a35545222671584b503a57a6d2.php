<?php $__env->startSection('title', 'Welcome Back'); ?>
<?php $__env->startSection('subtitle', 'Sign in to your Kuantan188 admin account'); ?>
<?php $__env->startSection('icon', 'login'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="email" class="form-label">Email Address</label>
        <input id="email" 
               type="email" 
               class="form-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="email" 
               value="<?php echo e(old('email')); ?>" 
               required 
               autocomplete="email" 
               autofocus
               placeholder="Enter your email">

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <span class="material-icons" style="font-size: 14px;">error</span>
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="password" class="form-label">Password</label>
        <input id="password" 
               type="password" 
               class="form-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="password" 
               required 
               autocomplete="current-password"
               placeholder="Enter your password">

        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <span class="material-icons" style="font-size: 14px;">error</span>
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="checkbox-group">
        <input class="checkbox-input" 
               type="checkbox" 
               name="remember" 
               id="remember" 
               <?php echo e(old('remember') ? 'checked' : ''); ?>>
        <label class="checkbox-label" for="remember">
            Remember me for 30 days
        </label>
    </div>

    <button type="submit" class="btn btn-primary">
        <span class="material-icons" style="font-size: 18px;">login</span>
        Sign In
    </button>

    <?php if(Route::has('password.request')): ?>
        <a class="forgot-password-link" href="<?php echo e(route('password.request')); ?>">
            Forgot your password?
        </a>
    <?php endif; ?>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <p class="auth-footer-text">
        Don't have an account? 
        <a href="<?php echo e(route('register')); ?>" class="auth-footer-link">Create one here</a>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kuantan188\kuantan188\backend\resources\views/auth/login.blade.php ENDPATH**/ ?>